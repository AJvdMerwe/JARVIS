# Changelog

All notable changes to the Virtual Personal Assistant are documented here.

---

## [1.0.0] — Initial Release

### Added

#### Core infrastructure
- **LLM Manager** — factory pattern with `@lru_cache` singleton; supports Ollama (local, CPU-friendly) and vLLM (OpenAI-compatible, high-throughput GPU server). Backend selected via `LLM_BACKEND` env var with zero code changes.
- **Conversation Memory** — sliding-window memory (`AssistantMemory`) and JSON-persisted session memory (`PersistentMemory`) built on `langchain-core` without legacy `langchain.memory` dependency.
- **Resilience layer** — `ResilientLLM` wrapping any `BaseChatModel` with: exponential back-off retry with jitter, hard per-call timeout, automatic primary→fallback backend switchover, and a `CircuitBreaker` FSM (CLOSED→OPEN→HALF_OPEN→CLOSED) to prevent hammering a degraded server.
- **Tool cache** — TTL-based `ToolCache` with per-tool TTL config, disk persistence across restarts, LRU eviction, hit/miss counters, and a `@cached_tool` decorator for wrapping `BaseTool._run()` methods.
- **Structured logging** — `JsonFormatter` emitting one JSON object per log line; `AssistantLogger` with `session_id` tagging and `agent_call()` context manager for automatic latency and outcome logging.

#### Voice
- **Whisper STT** — lazy-loaded Whisper model; supports file transcription and live microphone capture with energy-based VAD (voice activity detection). Configurable model size: `tiny` / `base` / `small` / `medium` / `large`.
- **pyttsx3 TTS** — fully offline text-to-speech with `SpeechSynthesiser` streaming helper that speaks sentence-by-sentence as tokens arrive.

#### Document processing
- **Docling integration** — converts PDF, DOCX, XLSX, and PPTX documents into structured `DocumentChunk` objects with page numbers and section breadcrumbs via Docling; falls back to `python-docx` / `openpyxl` / `python-pptx` if Docling is unavailable.
- **Vector store** — ChromaDB-backed store with: idempotent ingestion (SHA-256 chunk IDs deduplicate re-ingests), cosine similarity search, document-level retrieval, and a LangChain-compatible `BaseRetriever`.
- **Document manager** — high-level façade over processor + store; `format_search_results()` renders ranked hits with full `Title › Page N › Section` references.

#### Agents
- **`BaseAgent`** — abstract base implementing SOLID principles: `name`, `description`, `get_tools()`, `run()`. Shared `_build_react_agent()` helper builds LangChain ReAct executors. `AgentResponse` dataclass carries output, tool call log, references, and optional error.
- **`CodeAgent`** — writes, reviews, and executes code via `CodeWriterTool`, `CodeReviewTool`, and `CodeExecutorTool` (subprocess sandbox with blocked-pattern safety check).
- **`NewsAgent`** — aggregates RSS feeds and DuckDuckGo News; extracts URLs as references.
- **`SearchAgent`** — DuckDuckGo web search, Wikipedia lookup, web page fetch, and safe arithmetic evaluation.
- **`DocumentAgent`** — Docling ingestion, semantic search with chunk-level references, full document retrieval, knowledge base management.
- **`Orchestrator`** — two-stage routing (regex fast path → LLM intent classifier) dispatching to the correct specialist agent. Shared `PersistentMemory` across all agents per session. `build_graph()` returns a compiled LangGraph `StateGraph` for async / visualisation use.

#### API server
- **FastAPI REST** — `POST /chat`, `GET/DELETE /chat/{session_id}`, `POST /documents/ingest` (multipart upload), `GET /documents`, `DELETE /documents/{title}`, `GET /documents/search`, `GET /health`, `GET /metrics`.
- **WebSocket streaming** — `WS /ws/{session_id}` sends typed event stream: `start`, `token` (word-by-word), `reference`, `done`, `error`.
- **Rate limiter** — `RateLimitMiddleware` with sliding-window per-IP limits; `/health` and `/metrics` are exempt. Returns `X-RateLimit-*` headers on every response; `Retry-After` header on 429.

#### Web UI
- Single-file dark-mode chat interface (`ui/index.html`) with WebSocket streaming, token-by-token rendering, agent selector badge bar, document upload sidebar, reference display (clickable → pre-fills query), session clear, and toast notifications.

#### Evaluation harness
- **10 deterministic criteria**: `Contains`, `NotContains`, `MatchesRegex`, `NoError`, `UsedTools`, `HasReferences`, `MinLength`, `AgentIs`, `LLMJudge` (live LLM judge).
- **`EvalSuite` / `Evaluator` / `EvalReport`** — run suites, collect per-criterion results, export JSON reports.
- **Built-in suites**: `smoke`, `code`, `news`, `search`, `document`, `routing`, `all`.
- **CLI runner**: `python evaluation/run_evals.py --suite smoke --save`.

#### Plugin system
- `plugins/plugin_loader.py` — discovers `.py` files in `plugins/` directory and installed entry-points (`virtual_assistant.plugins` group). Calls `register_agents()` and `register_tools()` on each; `inject_into_orchestrator()` hot-loads agents into a running session.
- `plugins/example_calendar_plugin.py` — working demo plugin with `CalendarTool` and `CalendarAgent`.

#### Developer experience
- `Makefile` — `make run`, `make run-api`, `make test`, `make test-cov`, `make eval-smoke`, `make docker-build`, `make format`, `make typecheck`.
- `scripts/install.sh` — one-shot venv setup with Python version check and import sanity check.
- `scripts/setup_ollama.sh` — pulls configured Ollama models and waits for server health.
- `scripts/start_vllm.sh` — parameterised vLLM launch with quantisation support.
- `Dockerfile` + `docker-compose.yml` — multi-stage build; Compose stack with Ollama (CPU) and optional vLLM GPU profile.
- `pyproject.toml` — pytest, ruff, black, mypy, and coverage all configured.

#### Tests
- **167 tests** across 8 test files.
- `conftest.py` — `autouse` fixture prevents any test from accidentally calling a real LLM.
- `test_agents.py`, `test_tools.py`, `test_document_processing.py`, `test_voice.py`, `test_integration.py`, `test_new_modules.py`, `test_api.py`, `test_rate_limiter.py`.

---

## Dependency notes

- Requires **Python ≥ 3.10**.
- Uses **langchain-core ≥ 0.2** and **langchain ≥ 1.0** (no deprecated `langchain.memory`; uses `langchain_core.chat_history.InMemoryChatMessageHistory`).
- `sentence-transformers` must be installed for live embedding; tests mock it out.
- Whisper and sounddevice require system packages (`ffmpeg`, `portaudio19-dev`).
- See `requirements.txt` for the full pinned dependency list.
